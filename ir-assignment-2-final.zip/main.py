import os
import math
import re
from collections import defaultdict

# Function to calculate term frequency (logarithmic)
def nandhan_calculate_tf(term_freq):
    return 1 + math.log10(term_freq) if term_freq > 0 else 0

# Function to calculate inverse document frequency
def nandhan_calculate_idf(N, df):
    return math.log10(N / df) if df > 0 else 0

# Function to index documents from the corpus folder
def nandhan_index_documents_from_folder(folder_path):
    nandhan_dictionary = defaultdict(lambda: [0, []])  # term -> [df, [(docID, tf)]]
    nandhan_doc_lengths = defaultdict(float)  # docID -> document length
    nandhan_documents = {}  # To store the actual documents
    nandhan_doc_names = {}  # To store document names

    doc_id = 1
    for filename in os.listdir(folder_path):
        file_path = os.path.join(folder_path, filename)
        if os.path.isfile(file_path):  # Ensure it's a file, not a directory
            try:
                with open(file_path, 'r', encoding='utf-8') as file:
                    doc_text = file.read().lower()  # Read document and convert to lowercase
                    nandhan_documents[doc_id] = doc_text
                    nandhan_doc_names[doc_id] = filename  # Store the filename for the document
                    nandhan_term_freqs = defaultdict(int)

                    # Improved tokenization
                    terms = re.findall(r'\b\w+\b', doc_text)  # Tokenize and remove punctuation
                    for term in terms:
                        nandhan_term_freqs[term] += 1

                    # Update dictionary and postings list with term frequencies
                    for term, freq in nandhan_term_freqs.items():
                        tf_weight = nandhan_calculate_tf(freq)
                        nandhan_dictionary[term][0] += 1  # Increase document frequency (df)
                        nandhan_dictionary[term][1].append((doc_id, freq))

                        # Compute the length of the document vector (sum of squares of tf weights)
                        nandhan_doc_lengths[doc_id] += tf_weight ** 2

                    # Store document length as the square root of sum of squares
                    nandhan_doc_lengths[doc_id] = math.sqrt(nandhan_doc_lengths[doc_id])

                doc_id += 1
            except PermissionError as e:
                print(f"Permission denied: {file_path}")
            except Exception as e:
                print(f"Error reading file {file_path}: {e}")

    return nandhan_dictionary, nandhan_doc_lengths, nandhan_documents, nandhan_doc_names

# Function to list all documents in the corpus folder
def nandhan_list_documents_in_folder(folder_path):
    print("Documents in corpus:")
    for filename in os.listdir(folder_path):
        file_path = os.path.join(folder_path, filename)
        if os.path.isfile(file_path):
            print(f"Document: {filename}")

# Search function to find and rank documents by cosine similarity and tf-idf score
def nandhan_search(query, nandhan_dictionary, nandhan_doc_lengths, N, nandhan_doc_names):
    query_terms = re.findall(r'\b\w+\b', query.lower())  # Tokenize and remove punctuation
    nandhan_query_vector = defaultdict(float)

    # Build the query vector with tf-idf weights
    for term in query_terms:
        if term in nandhan_dictionary:
            df, _ = nandhan_dictionary[term]
            idf = nandhan_calculate_idf(N, df)
            nandhan_query_vector[term] = idf  # Assume tf for query terms is 1

    nandhan_scores = defaultdict(float)

    # Calculate cosine similarity scores for each document
    for term, query_weight in nandhan_query_vector.items():
        if term in nandhan_dictionary:
            df, postings = nandhan_dictionary[term]
            for doc_id, tf in postings:
                doc_weight = nandhan_calculate_tf(tf)  # lnc scheme for documents
                nandhan_scores[doc_id] += query_weight * doc_weight

    # Normalize by document length and rank by cosine similarity
    nandhan_ranked_docs = sorted(nandhan_scores.items(), key=lambda x: (-x[1] / nandhan_doc_lengths[x[0]], x[0]))

    # Return the top 10 documents (or fewer if there are less than 10) with their tf-idf scores
    return [(nandhan_doc_names[doc_id], nandhan_scores[doc_id] / nandhan_doc_lengths[doc_id]) for doc_id, _ in nandhan_ranked_docs[:10]]

# Main function to take a query and perform searching
def nandhan_main():
    # Use the absolute path to your corpus folder CHANGE AS PER YOUR DEVICE
    folder_path = r"C:\Users\Asus\OneDrive - Shiv Nadar Institution of Eminence\Documents\Corpus"

    # List all documents in the corpus folder
    nandhan_list_documents_in_folder(folder_path)

    # Index the documents in the corpus folder
    nandhan_dictionary, nandhan_doc_lengths, nandhan_documents, nandhan_doc_names = nandhan_index_documents_from_folder(folder_path)
    N = len(nandhan_documents)  # Total number of documents

    # Input a query from the user
    query = input("Enter your search query: ")

    # Perform the search and rank documents by relevance
    results = nandhan_search(query, nandhan_dictionary, nandhan_doc_lengths, N, nandhan_doc_names)

    # Output the top 10 ranked document names and tf-idf scores
    if results:
        print(f"Top {len(results)} relevant document(s):")
        for doc_name, tf_idf_score in results:
            print(f"Document '{doc_name}': tf-idf score = {tf_idf_score:.4f}")
    else:
        print("No documents match your query.")

if __name__ == "__main__":
    nandhan_main()
